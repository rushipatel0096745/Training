<?php 
    session_start();
    
    unset($_SESSION["admin1"]);

    header("Location: login.php");

?>