<?php 
    session_start();
    include '../database/db_connect.php';

    $email = $_POST["email"];
    $password = $_POST["password"];

    // $verify_password = password_verify()

    $emailErr = $passwordErr = $errMsg = "";

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        if(empty($_POST["email"])){
            $emailErr = "Email is required";
        } else {
            $email = $_POST["email"];
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $emailErr = "Invalid email format";
            }
        }
        if(empty($_POST["password"])){
            $passwordErr = "Password is required";
        } else {
            $password = $_POST["password"];
        }
        if($emailErr == "" and $passwordErr == ""){
            $sql = "SELECT admin_id from admin WHERE email = :email AND password_hash = :password";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(":email", $email);
            $stmt->bindParam(":password", $password);
            $stmt->execute();
            $res = $stmt->fetchColumn();
            
            if($res){
                $_SESSION["admin"] = $res;
                header("Location: dashboard.php");
                exit();
            } else {
                $errMsg = "Incorrect Email or Passoword";
            }
        }
        
    }
    // $conn = null;
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>admin-login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <body>
  <div class="container d-flex align-items-center justify-content-center vh-100"> 
            <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>" target="_blank" onsubmit="return submitHandler(event)">
                <div class="row mb-3 text-center">
                    <h1>Login</h1>
                </div>
                <div class="row mb-3">
                    <label for="email" class="col-sm-3 col-form-label">Email</label>
                    <div class="col-sm-9">
                    <input type="email" name="email" class="form-control req" id="inputEmail3">
                    <div class="text-danger" >
                        <?php echo $emailErr?>
                    </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-3 col-form-label">Password</label>
                    <div class="col-sm-9">
                    <input type="password" name="password" class="form-control req" id="inputPassword3">
                    <div class="text-danger" >
                        <?php echo $passwordErr?>
                    </div>
                    </div>
                </div>

                <div>
                        <span class="text-danger"><?php echo "$errMsg"; ?></span>
                </div>
                <div class="row mb-3 justify-content-center text-center" style="margin-top: 30px;">
                    <div class="col-auto">
                        <button type="submit" class="btn btn-primary">Login</button>
                    </div>
                </div>
        </form>

    </div>
    <script src="validation.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>