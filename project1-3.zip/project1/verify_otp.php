<?php 
    session_start();
    // if(!isset($_SESSION["reset_email"]) and !isset($_SESSION["reset_admin_id"])){
    //     header("Location: forget_password.php");
    //     exit();
    // }
?>

<?php 

    require './database/db_connect.php';

    $email = $_SESSION["reset_email"];
    $admin_id = $_SESSION["reset_admin_id"];
    $reset_id = $_SESSION["reset_id"];
    $errMsg = "";

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        if(empty($_POST["otp"])){
            $errMsg = "otp is required";
        } else {
            $otp = $_POST["otp"];
        }

        // fetcging values from db
        $sql = 'SELECT * FROM password_reset WHERE email = ? AND admin_id = ? AND id = ?';
        $stmt = $conn->prepare($sql);
        $stmt->execute([$email, $admin_id, $reset_id]);
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach($data as $d){
            $expiry = strtotime($d["expires_at"]);
            $otp_db = $d["otp"];
        }

        // check otp and its expiry
        $current_timestamp = time();
        if($otp == $otp_db and $expiry > $current_timestamp){
            header("Location: forget_reset_password.php");
            exit();
        } else {
            $errMsg = "OTP is incorrect or expired";
        }
    }

?>

<!doctype html>
<html lang="en" data-bs-theme="dark">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Password Reset</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <body>
    <div class="container d-flex align-items-center justify-content-center vh-100"> 
                <div class="card">
                    <div class="card-header">
                        Verify OTP
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>" onsubmit="return submitHandler(event)">
                            <label for="otp">Enter the otp</label>
                            <input type="text" name="otp" class="form-control otp">
                            <div class="text-danger"><?php echo $errMsg; ?></div>
                            <input type="submit" class="btn btn-primary mt-3"></input>
                        </form>
                    </div>
                </div>
    </div>
    <script>
        function submitHandler(event){
            const otp = document.querySelector(".otp");
            let divEle = otp.nextElementSibling;
            if(otp.value == ""){
                divEle.textContent = "otp is required"
                return false
            } else {
                divEle.textContent = "";
                return true
            }
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>