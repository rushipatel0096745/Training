<?php
    session_start();
    if(!isset($_SESSION["admin1"])){
        header("Location: ../login.php");
        exit();
    }
?>

<?php 

    require '../database/db_connect.php';
    $product_id = intval($_GET["p_id"]);



    // delete the product category first
    $delete_pc_sql = "DELETE FROM product_category WHERE p_id = ?";
    $delete_pc_stmt = $conn->prepare($delete_pc_sql);
    $delete_pc_stmt->execute([$product_id]);

    // delete the product 
    $delete_sql = "DELETE FROM product WHERE p_id = ?";
    $delete_stmt = $conn->prepare($delete_sql);
    $delete_stmt->execute([$product_id]);

    $_SESSION["success"] = "Product deleted successfully";
    header("Location: http://localhost/rushikesh/project1/products/products.php");
    exit();

?>