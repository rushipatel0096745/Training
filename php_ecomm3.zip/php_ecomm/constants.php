<?php 

// define("BASE_PATH", realpath(__DIR__));
// define('BASE_PATH', '/');

define("BASE_PATH", "/rushikesh/php_ecomm/");



?>