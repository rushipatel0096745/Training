<?php 
    session_start();
    require_once('../database/db_connect.php');
    require_once('../config/email_config.php');

    if (!isset($_SESSION["admin"])) {
        header("Location: login.php");
        exit();
    }

    $admin_id = $_SESSION["admin"];

    if ($admin_id != 1) {
        $_SESSION["error"] = "You don't have permission to add new admins";
        header("Location: dashboard.php");
        exit();
    }

    $name = $_POST['name'];
    $email = $_POST['email'];   
    $plain_password = $_POST['password'];
    $role = $_POST['role'];
    $err_msg = "";

    
    $password_hash = password_hash($plain_password, PASSWORD_DEFAULT);
    echo $name .  " "  . $email . " " .  $plain_password . " " . $role . " ". "$password_hash";

    $checkEmailSql = "SELECT email FROM admin WHERE email = :email";
    $check_email_stmt = $conn->prepare($checkEmailSql);
    $check_email_stmt->bindParam(":email", $email);
    $check_email_stmt->execute();
    $checkEmail = $check_email_stmt->fetchColumn();

    if($checkEmail){
        $err_msg = "Email is already in use";
        $_SESSION["error"] = $err_msg;
        header("Location: dashboard.php");
        exit();
    } else {

        try{
            $sql = "INSERT INTO admin (name, email, password_hash, role_id) VALUES (:name, :email, :password_hash, :role_id)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':password_hash', $password_hash);
            $stmt->bindParam(':role_id', $role);
            $stmt->execute();

            $mail = initializeMailer();
            if($mail){
                try{
                    $mail->setFrom('rp0096745@gmail.com', 'rushi patel');           
                    $mail->addAddress($email);
                    $mail->Subject = 'New Admin Account Created';
                    $mail->Body    = 'Your admin account has been created.<br><br>Email: ' . $email . '<br>Password: ' . $plain_password . '<br><br>Please login and change your password.';
                    $mail->AltBody = 'Your admin account has been created. Email: ' . $email . ' Password: ' . $plain_password . ' Please login and change your password.';
                    $mail->send();
                    $_SESSION["success"] = "Admin added successfully";
                    header("Location: dashboard.php");
                    exit();
                } catch(Exception $e){
                    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                }
            } else {
                echo "Email config error";
            }
        } catch (PDOException $e){
            echo $sql . "<br>" . $e->getMessage();
        }
    
           
    }

?>