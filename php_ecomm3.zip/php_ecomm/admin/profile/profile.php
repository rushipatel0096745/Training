<?php

    require '../../constants.php';


    session_start();
    if(!isset($_SESSION["admin"])){
        header("Location: " . BASE_PATH . "admin/login.php");
        exit();
    }
?>

<?php 

    ini_set('display_errors', 'On');
    error_reporting(E_ALL);
    require '../../database/db_connect.php';

    $login_user_id = $_SESSION["admin"];

    if($login_user_id == 1){
        $_SESSION["error"] = "Cannot edit administrator profile";
        header("Location: " . BASE_PATH . "admin/dashboard.php");
        exit();
    }

    // echo "Login user id :" . " " . $login_user_id;

    $rolesSql = "SELECT * FROM roles WHERE role_id != 1";
    $role_stmt = $conn->prepare($rolesSql);
    $role_stmt->execute();
    $roles = $role_stmt->fetchAll(PDO::FETCH_ASSOC);

    $errMsg = "";
    $nameErr = $emailErr = $roleErr = "";

    // fetching current user
    $login_user_sql = "SELECT * FROM admin WHERE admin_id = :admin_id";
    $login_user_stmt = $conn->prepare($login_user_sql);
    $login_user_stmt->bindParam(":admin_id", $login_user_id);
    $login_user_stmt->execute();
    $login_user = $login_user_stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach($login_user as $u){
        $name = $u["name"];
        $email = $u["email"];
        $password_hash = $u["password_hash"];
        $role_id = $u["role_id"];
    }

    // updating user
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        if(empty($_POST["name"])){
            $nameErr = "Name is required";
        } else {
            $new_name = $_POST["name"];
        }
        if(empty($_POST["email"])){
            $emailErr = "email is required";
        } else {
            $new_email = $_POST["email"];
        }
        if(empty($_POST["role"])){
            $roleErr = "Select the role";
        } else {
            $new_role = $_POST["role"];
        }

        if($errMsg ==  "") {
            if($new_email == $email) {
                $update_sql = "UPDATE admin SET name = ?, email = ?, role_id = ? WHERE admin_id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->execute([$new_name, $new_email, $new_role, $login_user_id]);

                // redirect on same page
                $_SESSION["success"] = "Updated successfully";
                header("Location: profile.php");
                exit();

            } elseif($new_email != $email) {
                $sql = "SELECT email FROM admin WHERE email = ?";
                $stmt = $conn->prepare($sql);
                $stmt->execute([$new_email]);
                $checkEmail = $stmt->fetchColumn();

                if(!$checkEmail){
                    $update_sql = "UPDATE admin SET name = ?, email = ?, role_id = ? WHERE admin_id = ?";
                    $update_stmt = $conn->prepare($update_sql);
                    $update_stmt->execute([$new_name, $new_email, $new_role, $login_user_id]);

                    // redirect on same page
                    $_SESSION["success"] = "Updated successfully";
                    header("Location: profile.php");
                    exit();

                } else {
                    $emailErr = "Email already exist";
                    // redirect on same page
                    $_SESSION["error"] = $emailErr;
                    header("Location: profile.php");
                    exit();
                }
            }
        }
        
    }

?>  

<!doctype html>
<html lang="en" data-bs-theme="dark">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <style>
   
  </style>
  <body>
    <div class="container-fluid p-0 m-0">

        <?php include '../../components/navbar.php'; ?>

        <div class="row mb-3">
            <?php if(isset($_SESSION["success"])){ ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php
                                if(isset($_SESSION['success'])){
                                    echo $_SESSION["success"]; 
                                    unset($_SESSION["success"]);
                                }
                            ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
            <?php }?>
            <?php if(isset($_SESSION["error"])){ ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php
                            if(isset($_SESSION['error'])){
                                echo $_SESSION["error"]; 
                                unset($_SESSION["error"]);
                            }
                        ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
            <?php }?>
        </div>
        <div class="container d-flex align-items-center justify-content-center vh-100 mb-0"> 
            <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
                <div class="row mb-3 text-center">
                    <h1>Profile</h1>
                </div>
                <div class="row mb-3">
                    <label for="name" class="col-sm-3 col-form-label">Name </label>
                    <div class="col-sm-9">
                    <input type="text" name="name" class="form-control req" id="inputEmail3" disabled value="<?php echo "$name"; ?>">
                    <div id="" >
                        <span class="bs-danger"><?php echo "$nameErr"; ?></span>
                    </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="email" class="col-sm-3 col-form-label">Email</label>
                    <div class="col-sm-9">
                    <input type="email" name="email" class="form-control req" id="inputEmail3" disabled value="<?php echo "$email"; ?>">
                    <div id="" >
                        <span class="bs-danger"><?php echo "$emailErr"; ?></span>
                    </div>
                    </div>
                </div>
                <div class="row mb-3">
                <label for="role" class="form-label col-sm-3">Select role</label>
                    <div class="col-sm-9">
                        <select name="role" id="" class="form-select form-select mb-3 req" disabled>
                            <option value="" >Select the role</option>
                            <?php  foreach($roles as $r){?>
                                <option <?php if($r["role_id"] == $role_id) echo "selected"; ?> value="<?php echo $r["role_id"] ?>"><?php echo $r["role_name"] ?>
                            <?php }?>
                        </select>
                        <div class="text-danger"><?php echo "$roleErr"; ?></div>
                    </div>
                </div>
                <div class="row mb-3 justify-content-center text-center">
                    <div>
                        <button type="submit" class="btn btn-primary mx-2">Submit</button>
                        <button class="btn btn-primary mx-2 edit">Edit</button>
                        <button type="button" class="btn btn-primary change-pass">
                          Change Password
                        </button>
                    </div>
                </div>
            </form> 
            <div class="row mb-3">
            </div>
        </div>
    </div>
    

    <script>
        let editBtn = document.querySelector(".edit");
        let allFields = document.querySelectorAll(".req");
        let showBtn = document.querySelector(".show1");
        let pass = document.querySelector(".pass");

        
        editBtn.addEventListener("click", function(event){
            event.preventDefault();
            allFields.forEach((field) => {
                if(field.hasAttribute('disabled')){
                    field.removeAttribute('disabled')
                } else {
                    field.disabled = true
                }
            })
        })

      document.querySelector(".change-pass").addEventListener("click", function () {
        window.location.href = "change_password.php";
      });

    </script>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>


