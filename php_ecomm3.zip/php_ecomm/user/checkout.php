<?php

    ini_set('display_errors', 'On');
    error_reporting(E_ALL);
    session_start();

    require '../database/db_connect.php';


    $login_user_id = $_SESSION["login_user_id"] ?? 0;
    // fetch cart items
    $cart_items = $_SESSION["cart"] ?? [];

    $cart_total = 0;
    if (empty($cart_items)) {
        $products = [];
    } else {
        $all_product_ids = array_keys($cart_items);
        $placeholder = array_fill(0, count($all_product_ids), "?");
        $placeholder = implode(",", $placeholder);

        $product_sql = "SELECT * FROM product WHERE p_id IN ($placeholder)";
        $product_stmt = $conn->prepare($product_sql);
        $product_stmt->execute($all_product_ids);
        $products = $product_stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($products as &$product) {
            $product["quantity"] = $cart_items[$product["p_id"]];
            $product["subtotal"] = $product["quantity"] * $product["price"];
            if($product["p_id"] == $product_id){
                $product_total = $product["subtotal"];
            }
            $cart_total += $product["subtotal"];
        }

        // insert into oreders 
        $insert_orders_sql = "INSERT INTO orders (user_id, order_total) VALUES (?,?)";
        $insert_orders_stmt = $conn->prepare($insert_orders_sql);
        $insert_orders_stmt->execute([$login_user_id, $cart_total]);
        $last_order_id = $conn->lastInsertId();

        echo var_dump($products);
        foreach($products as $pr){
            $insert_order_item_sql = "INSERT INTO order_items (order_id, p_id, quantity, unit_price) VALUES (?,?,?,?)";
            $insert_order_item_stmt = $conn->prepare($insert_order_item_sql);
            $insert_order_item_stmt->execute([$last_order_id, $pr["p_id"], $pr["quantity"], $pr["price"]]);
        }
    }
?>

