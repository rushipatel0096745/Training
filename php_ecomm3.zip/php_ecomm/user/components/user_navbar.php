<?php

ini_set('display_errors', 'On');
error_reporting(E_ALL);
require __DIR__ . '../../../database/db_connect.php';

// Fetch all navigation items
function fetchNavigationItems($conn)
{
    try {
        $sql = "SELECT * FROM navigation ORDER BY parent_id, id";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        return [];
    }
}


function buildTree($items, $parent_id = 0)
{
    $tree = [];
    foreach ($items as $item) {
        if ($item['parent_id'] == $parent_id) {
            $children = buildTree($items, $item['id']);
            if ($children) {
                $item['children'] = $children;
            }
            $tree[] = $item;
        }
    }
    return $tree;
}

// function renderNavigation($items, $is_dropdown = false)
// {
//     if (empty($items)) return '';

//     $class = $is_dropdown ? 'dropdown-menu' : 'navbar-nav';
//     $html = "<ul class='$class'>";

//     foreach ($items as $item) {
//         $hasChildren = isset($item['children']) && !empty($item['children']);

//         if ($hasChildren) {
//             // Parent with children (dropdown)
//             $html .= "<li class='nav-item dropdown'>";
//             $html .= "<a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>";
//             $html .= htmlspecialchars($item['name']);
//             $html .= "</a>";
//             $html .= renderNavigation($item['children'], true);
//             $html .= "</li>";
//         } else {
//             // Regular link
//             $itemClass = $is_dropdown ? 'dropdown-item' : 'nav-link';
//             $html .= "<li class='" . ($is_dropdown ? '' : 'nav-item') . "'>";
//             $html .= "<a class='$itemClass' href='" . htmlspecialchars($item['url']) . "'>";
//             $html .= htmlspecialchars($item['name']);
//             $html .= "</a>";
//             $html .= "</li>";
//         }
//     }

//     $html .= "</ul>";
//     return $html;
// }




// $navItems = fetchNavigationItems($conn);
// $navTree = buildTree($navItems);


$sql = "
    WITH RECURSIVE cte AS (
    
        SELECT 
            id, 
            parent_id, 
            name, 
            url,
            1 AS level 
        FROM 
            navigation
        WHERE 
            parent_id = 0
    
        UNION ALL
        
        SELECT 
            c.id, 
            c.parent_id, 
            c.name, 
            c.url,
            cte.level + 1
        FROM 
            navigation c
        INNER JOIN 
            cte ON c.parent_id = cte.id
    )
    SELECT 
        id, 
        parent_id, 
        name,
        url,
        level
    FROM
        cte
    ORDER BY 
        level, id
";


$stmt = $conn->prepare($sql);
$stmt->execute();
$res = $stmt->fetchAll(PDO::FETCH_ASSOC);

// echo var_dump($res);

$check = empty($res);
// echo "<br>" . $check;

// $tree1 = [];
// foreach ($res as $r) {
//     foreach($r as $u => $k){
//         echo $u . "=>" . $k . "<br>";
//     }
//     // if($r[])
// }


function buildTreeFromCTE($rows)
{
    $map = [];
    $tree = [];

    foreach ($rows as $row) {
        $row['children'] = [];
        $map[$row['id']] = $row;
    }

    foreach ($map as $id => &$node) {
        if ($node['parent_id'] == 0) {
            $tree[] = &$node;
        } else {
            $map[$node['parent_id']]['children'][] = &$node;
        }
    }

    return $tree;
}

function renderNavigation($items, $isDropdown = false)
{
    if (!$items) return '';

    $ulClass = $isDropdown ? 'dropdown-menu' : 'navbar-nav';
    $html = "<ul class='$ulClass'>";

    foreach ($items as $item) {
        $hasChildren = !empty($item['children']);

        if ($hasChildren) {
            $liClass   = $isDropdown ? 'dropdown-submenu' : 'nav-item dropdown';
            $linkClass = $isDropdown ? 'dropdown-item dropdown-toggle' : 'nav-link dropdown-toggle';

            $html .= "<li class='$liClass'>";
            $html .= "<a href='#' class='$linkClass nav-link' data-bs-toggle='dropdown'>";
            $html .= htmlspecialchars($item['name']);
            $html .= "</a>";
            $html .= renderNavigation($item['children'], true);
            $html .= "</li>";
        } else {
            $itemClass = $isDropdown ? 'dropdown-item' : 'nav-link';

            $html .= "<li class='" . ($isDropdown ? '' : 'nav-item') . "'>";
            $html .= "<a class='$itemClass nav-link' href='{$item['url']}'>";
            $html .= htmlspecialchars($item['name']);
            $html .= "</a>";
            $html .= "</li>";
        }
    }

    $html .= "</ul>";
    return $html;
}

$navTree = buildTreeFromCTE($res);





?>

<!-- <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="/">Navbar</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <?php // echo renderNavigation($navTree); 
            ?>
        </div>
    </div>
</nav> -->

<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">

        <a class="navbar-brand" href="http://localhost/rushikesh/php_ecomm/user/index.php">MySite</a>

        <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#mainNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav">
                <?php echo renderNavigation($navTree); ?>
            </ul>
            
        </div>
        <a href="http://localhost/rushikesh/php_ecomm/user/logout.php" class="btn btn-primary mx-2">Logout</a>
        <a href="http://localhost/rushikesh/php_ecomm/user/profile/profile.php" class="btn btn-primary">Profile</a>


    </div>
</nav>