<?php  
    ini_set('display_errors', 'On');
    error_reporting(E_ALL);
    require '../database/db_connect.php';

    $fnameErr = $lnameErr = $emailErr = $mobErr = $passwordErr = "";
            $first_name = "";
            $last_name = "";
            $email = "";
            $mob = "";
            $password = "";
            $errMsg = "";
            $signUpErr = "";

            // name
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // name
                if (empty($_POST["first_name"])) {
                    $nameErr = "First Name is required";
                } else {
                    $first_name = $_POST["first_name"];
                }     
                if (empty($_POST["last_name"])) {
                    $nameErr = "Last Name is required";
                } else {
                    $last_name = $_POST["last_name"];
                }               
                // email
                if (empty($_POST["email"])) {
                    $emailErr = "Email is required";
                } 
                else {
                    $email = $_POST["email"];
                    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $emailErr = "Invalid email format";
                    }
                } 
                //password
                if(empty($_POST["password"])) {
                    $passwordErr = "password is required";
                }
                else {
                    $password = $_POST['password'];
                }
                // mobile
                if(empty($_POST["mob"])){
                    $mobErr = "Phone no is required";
                }
                else {
                    $mob = $_POST['mob'];
                }
                if($fnameErr == "" and $lnameErr == "" and $mobErr == "" and $passwordErr == "" and $emailErr == ""){

                    $checkEmailSql = "SELECT email from users WHERE email = :email";
                    $checkEmailStmt = $conn->prepare($checkEmailSql);
                    $checkEmailStmt->bindParam(':email', $email);
                    $checkEmailStmt->execute();
                    $dbEmail = $checkEmailStmt->fetchAll(PDO::FETCH_ASSOC);

                    if($dbEmail){
                        $signUpErr = "user already exist";
                    } else {
                        try {
                        $password_hash = password_hash($password, PASSWORD_DEFAULT);
                         // prepare sql and bind parameters
                        $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, phone_no, password_hash)
                        VALUES (?,?,?,?,?)");
                        $stmt->execute([$first_name, $last_name, $email, $mob, $password_hash]);

                        echo "New records created successfully";

                        header("Location: ./login.php");
                        exit();
                        } catch (PDOException $e) {
                            echo "Error: " . $e->getMessage();
                        }   
                    }
                        $conn = null;
                }
                  
            } else {
                $nameErr = "";
                $passwordErr = "";
                $emailErr = "";
                $mobErr = "";
                $signUpErr = "";
            }

?>



<!doctype html>
<html lang="en" data-bs-theme="dark">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sign up</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <body>
    <div class="container d-flex align-items-center justify-content-center vh-100"> 
        
            <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>" class="" novalidate>
                <div class="row mb-3 text-center">
                    <h1>Registration</h1>
                </div>
                <div class="row mb-3">
                    <label for="first_name" class="col-sm-3 col-form-label">First name: </label>
                    <div class="col-sm-9">
                        <input type="text" name="first_name" class="form-control" id="inputEmail3" required>
                        <div id="" >
                            <span class="bs-danger"><?php echo "$fnameErr"; ?></span>
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="last_name" class="col-sm-3 col-form-label">Last name: </label>
                    <div class="col-sm-9">
                        <input type="text" name="last_name" class="form-control" id="inputEmail3" required>
                        <div id="" >
                            <span class="bs-danger"><?php echo "$lnameErr"; ?></span>
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="email" class="col-sm-3 col-form-label">Email</label>
                    <div class="col-sm-9">
                    <input type="email" name="email" class="form-control" id="inputEmail3">
                    <div id="" >
                        <span class="bs-danger"><?php echo "$emailErr"; ?></span>
                    </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="mob" class="col-sm-3 col-form-label">Phone no. </label>
                    <div class="col-sm-9">
                    <input type="tel" name="mob" class="form-control" id="inputEmail3">
                    <div id="" >
                        <span class="bs-danger"><?php echo "$mobErr"; ?></span>
                    </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-3 col-form-label">Password</label>
                    <div class="col-sm-9">
                    <input type="password" name="password" class="form-control" id="inputPassword3">
                    <div id="" >
                        <span class="bs-danger"><?php echo "$passwordErr"; ?></span>
                    </div>
                    </div>
                </div>

                <div id="" >
                        <span class="bs-danger"><?php echo "$signUpErr"; ?></span>
                </div>
                <div class="row mb-3 mt-3 justify-content-center text-center">
                    <div class="col sm-auto">
                        <button type="submit" class="btn btn-primary">Sign up</button>
                    </div>
                </div>
        </form>

    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>