<?php

session_start();

if (!isset($_SESSION["login_user_id"])) {
    header("Location: ./login.php");
    exit();
} else {
    $user_id = $_SESSION["login_user_id"];
}

require '../../database/db_connect.php';



$fnameErr = $lnameErr = $phoneErr = $emailErr = "";

// fetching current loggen in user
$current_user_sql = "SELECT * FROM users WHERE user_id = $user_id";
$current_user_stmt = $conn->prepare($current_user_sql);
$current_user_stmt->execute();
$user = $current_user_stmt->fetchAll(PDO::FETCH_ASSOC);

foreach($user as $u){
    $first_name = $u["first_name"];
    $last_name = $u["last_name"];
    $email = $u["email"];
    $phone_no = $u["phone_no"];
}




?>

<!doctype html>
<html lang="en" data-bs-theme="dark">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>

<body>

    <?php require '../../user/components/user_navbar.php'; ?>


    <div class="container d-flex align-items-center justify-content-center vh-100">

        <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" onsubmit="submit_handler(event)" novalidate>
            <div class="row mb-3 text-center">
                <h1>Profile</h1>
            </div>
            <div class="row mb-3">
                <label for="first_name" class="col-sm-3 col-form-label">First name: </label>
                <div class="col-sm-9">
                    <input type="text" name="first_name" class="form-control req" id="inputEmail3" value="<?php echo $first_name ?>" required disabled>
                    <div id="">
                        <span class="bs-danger"><?php echo "$fnameErr"; ?></span>
                    </div>
                </div>
            </div>
            <div class="row mb-3">
                <label for="last_name" class="col-sm-3 col-form-label">Last name: </label>
                <div class="col-sm-9">
                    <input type="text" name="last_name" class="form-control req" value="<?php echo $last_name ?>" id="inputEmail3" required disabled>
                    <div id="">
                        <span class="bs-danger"><?php echo "$lnameErr"; ?></span>
                    </div>
                </div>
            </div>
            <div class="row mb-3">
                <label for="email" class="col-sm-3 col-form-label">Email</label>
                <div class="col-sm-9">
                    <input type="email" name="email" class="form-control req" value="<?php echo $email ?>" id="inputEmail3" disabled>
                    <div id="">
                        <span class="bs-danger"><?php echo "$emailErr"; ?></span>
                    </div>
                </div>
            </div>
            <div class="row mb-3">
                <label for="mob" class="col-sm-3 col-form-label">Phone no. </label>
                <div class="col-sm-9">
                    <input type="tel" name="phone_no" class="form-control req" value="<?php echo $phone_no ?>" id="inputEmail3" disabled>
                    <div id="">
                        <span class="bs-danger"><?php echo "$phoneErr"; ?></span>
                    </div>
                </div>
            </div>
            <div class="row mb-3 justify-content-center text-center">
                <div>
                    <button type="submit" class="btn btn-primary mx-2">Submit</button>
                    <button class="btn btn-primary mx-2 edit">Edit</button>
                    <button type="button" class="btn btn-primary change-pass">
                        Change Password
                    </button>
                </div>
            </div>
        </form>

    </div>

    <script>
        let editBtn = document.querySelector(".edit");
        let allFields = document.querySelectorAll(".req");
        let showBtn = document.querySelector(".show1");
        let pass = document.querySelector(".pass");


        editBtn.addEventListener("click", function(event) {
            event.preventDefault();
            allFields.forEach((field) => {
                if (field.hasAttribute('disabled')) {
                    field.removeAttribute('disabled')
                } else {
                    field.disabled = true
                }
            })
        })

        document.querySelector(".change-pass").addEventListener("click", function() {
            window.location.href = "change_password.php";
        });


        function submit_handler(event){
            event.preventDefault();
            const formELe = event.target;
            console.log(formELe["first_name"].value);
            const formData = new FormData();
            formData.append("first_name", formELe["first_name"].value);
            formData.append("last_name", formELe["last_name"].value);
            formData.append("email", formELe["email"].value);
            formData.append("phone_no", formELe["phone_no"].value);

            const req = new XMLHttpRequest();
            req.open("POST", "./update_profile.php");
            req.send(formData);
            req.addEventListener("load", function(){
                // console.log(formData);
            })

        }
    </script>

    <script src="validation.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>

</html>