<?php 

    session_start();
    
    $product_id = intval($_POST["product_id"]);

    if(!isset($_SESSION["cart"])){
        $_SESSION["cart"] = [];
    } else {
        unset($_SESSION["cart"][$product_id]);
        echo "Product removed from cart";
    }

?>