<?php
    ini_set('display_errors', 'On');
    error_reporting(E_ALL);
    session_start();

    require_once __DIR__ . "../../../constants.php";
    require __DIR__ . '../../../database/db_connect.php';


    $product_id = intval($_POST["product_id"]);
    $action = $_POST["action"];

    if($action == "increase"){
        $_SESSION["cart"][$product_id]++;
    }
    if($action == "decrease"){
        $_SESSION["cart"][$product_id]--;
        if($_SESSION["cart"][$product_id] == 0){
            unset($_SESSION["cart"][$product_id]);
        }
    }

    // fetching all cart items
    $cart_items = $_SESSION["cart"] ?? [];

    $cart_total = 0;
    if (empty($cart_items)) {
        $products = [];
    } else {
        $all_product_ids = array_keys($cart_items);
        $placeholder = array_fill(0, count($all_product_ids), "?");
        $placeholder = implode(",", $placeholder);

        $product_sql = "SELECT * FROM product WHERE p_id IN ($placeholder)";
        $product_stmt = $conn->prepare($product_sql);
        $product_stmt->execute($all_product_ids);
        $products = $product_stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($products as &$product) {
            $product["quantity"] = $cart_items[$product["p_id"]];
            $product["subtotal"] = $product["quantity"] * $product["price"];
            if($product["p_id"] == $product_id){
                $product_total = $product["subtotal"];
            }
            $cart_total += $product["subtotal"];
        }
    }

    echo json_encode(["quantity" => $_SESSION["cart"][$product_id] ?? 0, "product_total" => $product_total ?? 0, "total" => $cart_total]);

?>